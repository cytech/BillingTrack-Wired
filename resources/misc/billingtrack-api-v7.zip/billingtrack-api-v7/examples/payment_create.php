<?php

// Require the API class.
require __DIR__ . '/../btapi.php';

// Require our API config variables.
require 'apiconfig.php';

// Create an instance of the API client library.
$btapi = new btapi($baseURL, $apiPublicKey, $apiSecretKey);

// Issue the command to create the record.
// Required fields: invoice_id, amount, payment_method_id, paid_at (YYYY-MM-DD format).
$btapi->createPayment(['invoice_id' => 15, 'amount' => 1044.44, 'payment_method_id' => 1, 'paid_at' => '2023-01-25']);

// Was the request successful?
if ($btapi->getHttpStatus() == 200)
{
    // It was successful, and here's the new record in case we need to do anything else with it.
    $payment = $btapi->getResponse();

    var_dump($payment);
}
else
{
    // It was not successful. Let's check the messages to see what went wrong.
    $errors = $btapi->getResponse();

    var_dump($errors);
}
