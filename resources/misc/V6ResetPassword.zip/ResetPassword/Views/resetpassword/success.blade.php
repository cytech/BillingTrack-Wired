<!DOCTYPE html>
<html>
<head>
    <link href="{{ asset('favicon.png') }}" rel="icon" type="image/png">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('bt.welcome') }}</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body class="login-page">
<div class="login-box">
    <div class="login-box-body">
        <p class="login-box-msg">BillingTrack Password Reset Utility</p>
        <p>Your password has successfully been reset.</p>
        <p><strong>Delete the /app/Modules/ResetPassword folder from your
                server - otherwise anybody who finds this will be able to reset your password.</strong></p>
        <p><a href="{{ route('session.login') }}">Log In</a></p>
    </div>
</div>
</body>
</html>
