<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('bt.welcome') }}</title>
    <link rel="stylesheet" href="/build/assets/app.css">
</head>
<body class="login-page">
<div class="login-box">
    <div class="login-box-body">
        <p class="login-box-msg">BillingTrack Password Reset Utility</p>
{{--        {!! Form::open() !!}--}}
        {{ html()->form()->open() }}
        <div class="form-group has-feedback">
            <label>Enter your BillingTrack email address:</label>
            <input type="email" name="email" id="email" class="form-control">
            @if($errors->has('email'))
                <div class="text-red">{{ $errors->first('email') }}</div>
            @endif
        </div>
        <div class="form-group has-feedback">
            <label>Enter your new password:</label>
            <input type="password" name="password" class="form-control">
            @if($errors->has('password'))
                <div class="text-red">{{ $errors->first('password') }}</div>
            @endif
        </div>
        <div class="row">
            <div class="col-xs-6">
            </div>
            <div class="col-xs-6">
                <button type="submit"
                        class="btn btn-primary btn-block btn-flat">{{ trans('bt.reset_password') }}</button>
            </div>
        </div>
{{--        {!! Form::close() !!}--}}
        {{ html()->form()->close() }}
    </div>
</div>
</body>
</html>
