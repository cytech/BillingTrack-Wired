<?php

// Require the API class.
require __DIR__ . '/../btapi.php';

// Require our API config variables.
require 'apiconfig.php';

// Create an instance of the API client library.
$btapi = new btapi($baseURL, $apiPublicKey, $apiSecretKey);

// Attempt to retrieve a payment by id.
$btapi->showPayment(['id' => 1]);

if ($btapi->getHttpStatus() == 200)
{
    // It was successful, and here's the payment record.
    $payment = $btapi->getResponse();

    var_dump($payment);
}
else
{
    // It was not successful. Let's check the messages to see what went wrong.
    $messages = $btapi->getResponse();

    var_dump($messages);
}
