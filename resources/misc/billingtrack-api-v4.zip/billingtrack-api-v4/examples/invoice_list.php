<?php

// Require the API class.
require __DIR__ . '/../btapi.php';

// Require our API config variables.
require 'apiconfig.php';

// Create an instance of the API client library.
$btapi = new btapi($baseURL, $apiPublicKey, $apiSecretKey);

// Issue the command to retrieve a paginated list of records.
$btapi->listInvoices(['page' => 1]);

// Was the request successful?
if ($btapi->getHttpStatus() == 200)
{
    // It was successful.
    $result = $btapi->getResponse();

    // $result contains pagination information (total, last_page, etc).
    // $result['data'] contains the actual records.
    var_dump($result);
}
else
{
    // It was not successful. Let's check the messages to see what went wrong.
    $errors = $btapi->getResponse();

    var_dump($errors);
}
