<?php

// Require the API class.
require __DIR__ . '/../btapi.php';

// Require our API config variables.
require 'apiconfig.php';

// Create an instance of the API client library.
$btapi = new btapi($baseURL, $apiPublicKey, $apiSecretKey);

// Attempt to retrieve a client by id.
$btapi->showClient(['id' => 41]);

if ($btapi->getHttpStatus() == 200)
{
    // It was successful, and here's the client record.
    $client = $btapi->getResponse();

    var_dump($client);
}
else
{
    // It was not successful. Let's check the messages to see what went wrong.
    $messages = $btapi->getResponse();

    var_dump($messages);
}
